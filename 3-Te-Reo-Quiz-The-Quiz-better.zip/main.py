# Version 1, Hayden French, 15.06.2021, Line 1 (Importing time and os for the quiz)
import time
import os



# Version 1, Hayden French, 15.06.2021, Line 2 (Telling them there words to remember)

def beginner_quiz():
  os.system('clear')
  print("Kia ora good luck with the quiz")
  print()
  print("Remember these words.")
  print()
  print("Your words are - Hello (Kia Ora), Food (Kai), Mountain (Maunga)")
  print()
  print("Please do not type or touch the screen!")
  time.sleep(15)
  os.system('clear')
  answer_hello()



# Version 1, Hayden French, 15.06.2021, Line 3 (Asking what hello is)
def answer_hello():
  os.system('clear')
  hello_answer("What is 'Hello' in Te Reo? ")


# Version 1, Hayden French, 15.06.2021, Line 4 (defining the answer as a question so we can make sure they can continue even if they get the wrong answer)
def hello_answer(question):  
  valid = False
  while not valid:
    hello = input(question).lower()

    if hello == "Kia ora" or hello == "kia ora":
      
      
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      os.system('clear')
      
      print("Tēnā koutou you are correct!")
      time.sleep(2)
      answer_mountain()
      break  
    

    else:
      print()
      print("Try Again")


# Version 1, Hayden French, 15.06.2021, Line 5 (Asking what mountain is)
def answer_mountain():
  os.system('clear')
  mountain_answer("What is 'Mountain' in Te Reo? ")


# Version 1, Hayden French, 15.06.2021, Line 6 (defining the answer as a question so we can make sure they can continue even if they get the wrong answer)
def mountain_answer(question):  
  valid = False
  while not valid:
    mountain = input(question).lower()

    if mountain == "Maunga" or mountain == "maunga":
      
      
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print("r")
      time.sleep(0.3)
      print("o")
      time.sleep(0.3)
      print("c")
      time.sleep(0.3)
      print("e")
      time.sleep(0.3)
      print("s")
      time.sleep(0.3)
      print("s")
      time.sleep(0.3)
      print("i")
      time.sleep(0.3)
      print("n")
      time.sleep(0.3)
      print("g")
      time.sleep(0.3)
      print(".")
      time.sleep(0.3)
      print(".")
      time.sleep(0.3)
      print(".")
      time.sleep(2)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      answer_food()
      break

     

    else:
      print("Try Again")




# Version 1, Hayden French, 15.06.2021, Line 7 (Asking what food is)
def answer_food():
  os.system('clear')
  food_answer("What is 'Food' in Te Reo? ")



# Version 1, Hayden French, 15.06.2021, Line 8 (defining the answer as a question so we can make sure they can continue even if they get the wrong answer and will continue into part 2 of beginners quiz)
def food_answer(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Kai" or food == "kai":
      
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("o")
      time.sleep(0.3)
      print(" c")
      time.sleep(0.3)
      print("e")
      time.sleep(0.3)
      print(" s")
      time.sleep(0.3)
      print("s")
      time.sleep(0.3)
      print(" i")
      time.sleep(0.3)
      print("n")
      time.sleep(0.3)
      print(" g")
      time.sleep(0.3)
      print(".")
      time.sleep(0.3)
      print(" .")
      time.sleep(0.3)
      print(".")
      time.sleep(3)
      
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(5)
      os.system('clear')
      print("Congratulations you passed part 1 of beginner!")
      time.sleep(10)
      os.system('clear')
      print("Would you like to continue with part 2 of the beginner quiz to increase ")
      print("your Te Reo vocabulary, or would you like to move on to intermediate, ")
      print("or would you prefer to quit?")
      print()
      print
      Choosing_Options("Options - 'Continue' 'Intermediate' 'Quit' ")
      
      

      break  

    else:
      print("Please type an appropriate answer.")



def Choosing_Options(question):  
  valid = False
  while not valid:
    Option = input(question).lower()

    if Option == "c" or Option == "Continue":
      continue_beginner()
      break  

    if Option == "i" or Option == "Intermediate":
      intermediate_quiz()
      break


    if Option == "q" or Option == "quit":
      print("Ok bye")
      break
  
    else:
      print()
      print("Please pick 'Continue' 'Intermediate' 'Quit' ")    




def continue_beginner():
  os.system('clear')
  print("Welcome To Part 2 of this beginner quiz.")
  print("Here are your words - Good Morning (Ata marie), Good Night (Po marie), House (Whare)")
  print("Remember these.")
  time.sleep(10)
  os.system('clear')
  good_morning_answer()



def good_morning_answer():
  os.system('clear')
  answer_good_morning("What is 'Good Morning' in Te Reo? ")



def answer_good_morning(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Ata marie" or food == "ata marie":
    
     
      
      time.sleep(1)
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      print()
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      good_night_answer()
      break  

    else:
      print("Try Again")



def good_night_answer():
  os.system('clear')
  answer_good_night("What is 'Good night' in Te Reo? ")



def answer_good_night(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Po marie" or food == "po marie":
      
    

      
      time.sleep(1)
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      print()
      print("Tēnā koutou you are correct!")
      house_answer()
      break  

    else:
      print("Try Again")



def house_answer():
  os.system('clear')
  answer_house("What is 'House' in Te Reo? ")



def answer_house(question):  
  valid = False
  while not valid:
    house = input(question).lower()

    if house == "Whare" or house == "whare":
      
      
      time.sleep(1)
      os.system('clear')
      time.sleep(0.3)
      print("p")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      os.system('clear')
      
      
      print("Tēnā koutou you are correct!")
      
      print("Congratulations you have passed part 2 of Beginner quiz this is ")
      print("easiet quiz so you should try intermediate next.")
      print()
      print("Please reset to try a new quiz... ")
      break  

    else:
      print("Try Again")



def intermediate_quiz():
  
  os.system('clear')
  print("Nau mai, Welcome to the intermediate quiz. Things ")
  print("are a bit different around here and the quiz setup ")  
  intermediate_demonstration("is a bit different would you like to see a demonstration? ")




def intermediate_demonstration(question):  
  valid = False
  while not valid:
    intermediate_demonstration = input(question).lower()

    if intermediate_demonstration == "y" or intermediate_demonstration == "yes":
      demonstration_quiz()
      

    

    else:
      print("Try Again")
      

def demonstration_quiz():
  os.system('clear')
  print("Unlike the beginner quiz you wont be given a set of words to ")
  print("remember, instead you will get 4 options to choose from.")
  time.sleep(10)
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("4. Waea")
  print()
  print("Please type answer here: <---- (You then write your answer in\n")

  time.sleep(5)
  print()
  print("Please type answer here: Purutaringa <---- (This is the answer)\n")
  print()
  print("Congratulations your correct! <---- (You will then be congratulated")
  print()
  print("A score will alos be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("This is what the quiz will be like")
  print()
  intermediate_options("Would you like to start the quiz? ")
  




def intermediate_options(question):  
  valid = False
  while not valid:
    intermediate_options = input(question).lower()

    if intermediate_options == "y" or intermediate_options == "yes":
      quiz_intermediate()
      break
    
    if intermediate_options == "n" or intermediate_options == "no":
      quiz_options()
      break
    
      

    else:
      print("Try Again")





def quiz_intermediate():  
  os.system('clear')
  print("Kia ora, Chur, Hello welcome to the intermediate quiz! ")
  print("Lets get straight into this quiz, waimarie!")
  good_luck_answer()
  time.sleep(15)
  

def quiz_options():
  print("sup")


def good_luck_answer():
  time.sleep(5)
  os.system('clear')
  print("1) Waimarie")
  print()
  print("2) Koa")
  print()
  print("3) Taringa")
  print()
  print("4) Ika")
  print()
  print("What is 'good luck' in Te Reo? ")
  answer_good_luck("Please type answer here: " )
   


score = 0

def score_checker(score):
  score = 0
  score_checker = True
  if score_checker == True:
    score = score+1









def answer_good_luck(question):  
  valid = False
  while not valid:
    good_luck = input(question).lower()

    if good_luck == "waimarie" or good_luck == "1":
      print("Tumeke! You sure your a intermediate?")
      score_checker == True
     
      score_checker(score)
      time.sleep(3)
      sister_answer()
      break

    else:
      print("Try Again")


def sister_answer():
  time.sleep(5)
  os.system('clear')
  print("Next question...")
  print()
  print("1) Brother")
  print()
  print("2) Dad")
  print()
  print("3) Sister")
  print()
  print("4) Mum")
  print()
  print("What is the English translation for 'Tuahine'? ")
  answer_sister("Please type answer here: ")


 

def answer_sister(question):  
  valid = False
  while not valid:
    sister = input(question).lower()

    if sister == "sister" or sister == "3":
      print()
      print("Ka pai, to easy!")
      time.sleep(3)
      sister_answer()
      break

    else:
      print("Try Again")
 


# Version 1, Hayden French, 15.06.2021, Line 9 (To start the actual quiz up)
print("Lets start with a quiz")
print("Press Enter To Continue...")
start = input()

if start == "":
  beginner_quiz() 