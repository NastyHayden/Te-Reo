# Version 1, Hayden French, 15.06.2021, Line 1 (what level are you at?)
import time
import os

# Version 1, Hayden French, 29.06.2021, Line 2 (Defining a question so that when you type an answer thats not valid it will say 'Please pick a sensible answer!')
def yes_no(question):  
  valid = False
  while not valid:
    response = input(question).lower()

    if response == "beginner" or response == "b":
      response == "beginner"
      level_beginners()
      break

    if response == "intermediate" or response == "i":
      response == "intermediate"
      level_intermediates()
      break
    
    if response == "advanced" or response == "a":
      response == "advanced"
      level_advanced()
      break

    else:
      print("Please pick a sensible answer!")


def yes_no_quiz_beginner(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "yes" or demonstration == "y":
      beginner_demonstrations()
      break  

    elif demonstration == "no" or demonstration == "n":
      quiz_beginner()
      break

      
    
    else:
      print("Please pick a sensible answer!")



def yes_no_quiz_intermediate(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "yes" or demonstration == "y":
      intermediate_demonstrations()
      break

    elif demonstration == "no" or demonstration == "n":
      quiz_intermediate()
      break

      
    
    else:
      print("Please pick a sensible answer!")

  

def yes_no_quiz_advanced(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "yes" or demonstration == "y":
      advanced_demonstrations()
      break

    elif demonstration == "no" or demonstration == "n":
      quiz_advanced()
      break

      
    
    else:
      print("Please pick a sensible answer!")


def embark_quiz_beginner(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "yes" or demonstration == "y":
      quiz_beginner()
      break  

    elif demonstration == "no" or demonstration == "n":
      print("Ok bye...")
      break

      
    
    else:
      print("Please pick a sensible answer!")
  

def embark_quiz_intermediate(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "yes" or demonstration == "y":
      quiz_intermediate()
      break  

    elif demonstration == "no" or demonstration == "n":
      print("Ok bye...")
      break
      
    
    else:
      print("Please pick a sensible answer!")
 


def embark_quiz_advanced(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "yes" or demonstration == "y":
      quiz_advanced()
      break  

    elif demonstration == "no" or demonstration == "n":
      print("Ok bye...")
      break

      
    
    else:
      print("Please pick a sensible answer!")


# Version 1, Hayden French, 29.06.2021, Line 3 (Defining level and choosing where you want to start, 3 options beginner, intermediate, advanced. Choose 1 else you will not be able to continue)
def level():
  print()
  print("*** Level Determination ***")
  print()
  print("There are 3 levels of learning beginner, intermediate, advanced")
  yes_no("What level of Te Reo Maori do you think your at? ")

  return""
  


# Version 1, Hayden French, 29.06.2021, Line 4 (This is beginner quiz if you chose beginner and there is also a demonstraion if wanted else go straight into the quiz)
def level_beginners():
  print()
  print("*** Beginner Quiz ***")
  print()
  print("Ok beginner, lets start off with a basic quiz. ")
  print()
  
  yes_no_quiz_beginner("Would you like to see a demonstration? ")





# Version 1, Hayden French, 29.06.2021, Line 5 (This is intermediate quiz if you chose intermediate and there is also a demonstration if wanted else go straight into the quiz)
def level_intermediates():
  print()
  print("*** Intermediate Quiz ***")
  print()
  
  yes_no_quiz_intermediate("Would you like to see a demonstration? ")
  
  
  

def level_advanced():
  print()
  print("*** Patapatai matatau ***")
  print()
  yes_no_quiz_advanced("Kia Ora toku hoa, e hiahia ana koe kia kite i te rewera rewera? ")

 



# Version 1, Hayden French, 29.06.2021, Line 6 (This is the beginner demonstartion showing a beginner question and demonstration)
def beginner_demonstrations():
  
  print()
  print("Hi this is demonstration bot here to demonstrate how to play.")
  print()
  print("Please do not type or touch the screen!")
  print()
  print("Lets begin:")
  print()
  print("here are your set of words, Kia ora (Hello), Ka pai (Good), Tangata (Man). ")
  time.sleep(3)
  print()
  print("What is Kia ora in Te Reo?")
  time.sleep(2)
  print()
  print("Hello")
  time.sleep(2)
  print()
  print("Your Correct!")
  print()
  print('This will go on until all questions are answered.')
  embark_quiz_beginner("Are you ready to embark on this quiz? ")
 
 
  



# Version 1, Hayden French, 29.06.2021, Line 7 (An intermediate demonstration and question)
def intermediate_demonstrations():
  
  print()
  print("Hi this is demonstration bot here to demonstrate how to play.")
  print()
  print("Please do not type or touch the screen!")
  print()
  print("Lets begin:")
  print()
  print("here are your set of words, Kia ora (Hello), Ka pai (Good), Tangata (Man). ")
  time.sleep(3)
  print()
  print("What is Kia ora in Te Reo?")
  time.sleep(2)
  print()
  print("Hello")
  time.sleep(2)
  print()
  print("Your Correct!")
  print()
  print('This will go on until all questions are answered.')
  embark_quiz_intermediate("Are you ready to embark on this quiz? ")
 



def advanced_demonstrations():
  print()
  print("Hi this is demonstration bot here to demonstrate how to play.")
  print()
  print("Please do not type or touch the screen!")
  print("Lets begin:")
  print()
  print("here are your set of words, Kia ora (Hello), Ka pai (Good), Tangata (Man). ")
  time.sleep(3)
  os.system('clear')
  print()
  print("What is Kia ora in Te Reo?")
  time.sleep(2)
  print()
  print("Hello")
  time.sleep(2)
  print()
  print("Your Correct!")
  print()
  print('This will go on until all questions are answered.')
  embark_quiz_advanced("Are you ready to embark on this quiz? ")




# Version 1, Hayden French, 29.06.2021, Line 8 (intermediate quiz)
def quiz_intermediate():
  print()
  print("Ok Lets start with a quiz")



# Version 1, Hayden French, 29.06.2021, Line 9 (beginner quiz)
def quiz_beginner():
  print()
  print("Ok Lets start with a quiz")


# Version 1, Hayden French, 29.06.2021, Line 10 (advanced quiz)
def quiz_advanced():
  print()
  print("Ok Lets start with a quiz")


# Version 1, Hayden French, 29.06.2021, Line 9 (This is lower down because of defining and how it works but acts as one of the first lines of code)
print("Lets determine your level of Te Reo Maori")
print("Press Enter to continue... ")
confidence = input()
if confidence == "":
  level()

else:
  print("Just press enter please")
  
