import os
import time

def demonstration_quiz():
  os.system('clear')
  print("In the beginner quiz you were give words to remember but for this you will have a set of words to remember, and you will choose one of those options.")
  print()
  next_slide("Press enter to continue ")
  
def next_slide(question):
  valid = False
  while not valid:
    slide_next = input(question).lower()
    if slide_next == "" or slide_next == " ":
      this_next_slide()
      break

    else:
      print("Please press enter ")
      break

def this_next_slide():
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("4. Waea")
  print()
  print("Please type answer here: <---- (You then write your answer in")

  time.sleep(5)
  print()
  print("Please type answer here: Purutaringa <---- (This is the answer)")
  print()
  print("Congratulations your correct! <---- (You will then be congratulated")
  print()
  print("A score will also be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("------------------------------------------------------")
  print()
  quiz_intermediates("Would you like to play? ")
 

def quiz_intermediates(question):
  valid = False
  while not valid:
    quiz_thing = input(question).lower()
    if quiz_thing == "y" or quiz_thing == "y":
      os.system('clear')
      quiz_intermediate()
      break

    if quiz_thing == "no" or quiz_thing == "n":
      os.system('clear')
      quiz_options()
      break


def quiz_options():
  quiz_option("You have the option to quit or try a different level what would you like to do? (Quit / Change level) ")


def quiz_option(question):
  valid = False
  while not valid:
    quiz_options = input(question).lower()
    if quiz_options == "Change level" or quiz_options == "c l":
      os.system('clear')
      level_choose()
      break

    if quiz_options == "Quit" or quiz_options == "q":
      os.system('clear')
      quit_game()
      break



def quit_game():
  os.system('clear')
  print("Tumeke! For giving the quiz a try, hope to see you again. Bye...")
  


def quiz_intermediate():
  # This defines the functions
  class Te_Reo_Question:
    def __init__(self, prompt, answer):
      # These define for prompt and answer these store information for a question
      self.prompt = prompt
      self.answer = answer


  # These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
  questions_prompts = [
    "What is Wahine is English?\n(1) Sister\n(2) Women / Female\n(3) Boat\n Answer Here: ",
    "\nWhat is Waka is English?\n(1) House\n(2) Toilet\n(3) Boat\n Answer Here: ",
    "\nWhat is Water is Te Reo?\n(1) Wai\n(2) Whare\n(3) Ika\n Answer Here: ",
    "\nWhat is Waimarie is English?\n(1) Happy\n(2) Luck\n(3) Good Luck\n Answer Here: ",
    "\nWhat is Computer is Te Reo?\n(1) Rorohiko\n(2) Rooroohiko\n(3) Roroheko\n Answer Here: ",  
    "\nWhat is Headphones is Te Reo?\n(1) Taringa\n(2) Pokitaringa\n(3) Kai\n Answer Here: ",
    "\nWhat is Tangi is English?\n(1) Sad\n(2) Death\n(3) Funeral\n Answer Here: ",
    "\nWhat is Happy is Te Reo?\n(1) Koa\n(2) Tumeke\n(3) Tena Koe\n Answer Here: ",
  ]


  # This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
  questions = [
    Te_Reo_Question(questions_prompts[0], "2"),
    Te_Reo_Question(questions_prompts[1], "3"),
    Te_Reo_Question(questions_prompts[2], "1"),
    Te_Reo_Question(questions_prompts[3], "3"),
    Te_Reo_Question(questions_prompts[4], "1"),
    Te_Reo_Question(questions_prompts[5], "2"),
    Te_Reo_Question(questions_prompts[6], "3"),
    Te_Reo_Question(questions_prompts[7], "1"),
    
    
  ]



  # This code will simply go through each question add a score and then tell you what your score was as the end.
  def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
    # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
    score = 0
    # For each question in questions it will do something which is told in the next code.
    for question in questions:
      # Ask user question then store response in a variable (answer)
      answer = input(question.prompt)
      # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
      if answer == question.answer:
        score += 1
      
      
        
    # This show how many questions they got right (have to use str since its a number for the score.))
    print()
    print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")


  # This is to run the quiz this is all of the code from run_test to start the quiz.
  run_test(questions)







demonstration_quiz()











