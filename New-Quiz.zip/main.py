# Version 1, Hayden French, 15.06.2021, Line 1 (Importing time and os for the quiz)
import time
import os



# Version 1, Hayden French, 15.06.2021, Line 2 (Telling them there words to remember)

def beginner_quiz():
  os.system('clear')
  print("Kia ora good luck with the quiz")
  print()
  print("Remember these words.")
  print()
  print("Your words are - Hello (Kia Ora), Food (Kai), Mountain (Maunga)")
  print()
  print("Please do not type or touch on the screen!")
  time.sleep(15)
  os.system('clear')
  answer_hello()



# Version 1, Hayden French, 15.06.2021, Line 3 (Asking what hello is)
def answer_hello():
  os.system('clear')
  hello_answer("What is 'Hello' in Te Reo? ")


# Version 1, Hayden French, 15.06.2021, Line 4 (defining the answer as a question so we can make sure they can continue even if they get the wrong answer)
def hello_answer(question):  
  valid = False
  while not valid:
    hello = input(question).lower()

    if hello == "Kia ora" or hello == "kia ora":
      
      
      os.system('clear')
      print("processing...")
      time.sleep(3)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      answer_mountain()
      break  
    

    else:
      print()
      print("Try Again")


# Version 1, Hayden French, 15.06.2021, Line 5 (Asking what mountain is)
def answer_mountain():
  os.system('clear')
  mountain_answer("What is 'Mountain' in Te Reo? ")


# Version 1, Hayden French, 15.06.2021, Line 6 (defining the answer as a question so we can make sure they can continue even if they get the wrong answer)
def mountain_answer(question):  
  valid = False
  while not valid:
    mountain = input(question).lower()

    if mountain == "Maunga" or mountain == "maunga":
      os.system('clear')
      print("processing...")
      time.sleep(3)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      answer_food()
      break

     

    else:
      print("Try Again")




# Version 1, Hayden French, 15.06.2021, Line 7 (Asking what food is)
def answer_food():
  os.system('clear')
  food_answer("What is 'Food' in Te Reo? ")



# Version 1, Hayden French, 15.06.2021, Line 8 (defining the answer as a question so we can make sure they can continue even if they get the wrong answer and will continue into part 2 of beginners quiz)
def food_answer(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Kai" or food == "kai":
      
      os.system('clear')
      print("processing...")
      time.sleep(3)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      os.system('clear')
      print("Congratulations you passed part 1 of beginner!")
      time.sleep(5)
      os.system('clear')
      print("Would you like to continue with part 2 of the beginner quiz to increase your Te Reo vocabulary, or would you like to move on to intermediate, or would you prefer to quit?")
      print()
      Choosing_Options("Options - 'Continue' 'Intermediate' 'Quit' ")
      
      

      break  

    else:
      print("Please type an appropriate answer.")



def Choosing_Options(question):  
  valid = False
  while not valid:
    Option = input(question).lower()

    if Option == "c" or Option == "Continue":
      continue_beginner()
      break  

    if Option == "i" or Option == "Intermediate":
      intermediate_quiz()
      break


    if Option == "q" or Option == "quit":
      print("Ok bye")
      break
  
    else:
      print()
      print("Please pick 'Continue' 'Intermediate' 'Quit' ")    




def continue_beginner():
  os.system('clear')
  print("Welcome To Part 2 of this beginner quiz.")
  print("Here are your words - Good Morning (Ata marie), Good Night (Po marie), House (Whare)")
  print("Remember these.")
  time.sleep(10)
  os.system('clear')
  good_morning_answer()



def good_morning_answer():
  os.system('clear')
  answer_good_morning("What is 'Good Morning' in Te Reo? ")



def answer_good_morning(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Ata marie" or food == "ata marie":
    
     
      
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      good_night_answer()
      break  

    else:
      print("Try Again")



def good_night_answer():
  os.system('clear')
  answer_good_night("What is 'Good night' in Te Reo? ")



def answer_good_night(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Po marie" or food == "po marie":
      
    
      os.system('clear')
      time.sleep(0.3)
      print("P")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      house_answer()
      break  

    else:
      print("Try Again")



def house_answer():
  os.system('clear')
  answer_house("What is 'House' in Te Reo? ")



def answer_house(question):  
  valid = False
  while not valid:
    house = input(question).lower()

    if house == "Whare" or house == "whare":
      
    
      os.system('clear')
      time.sleep(0.3)
      print("p")
      time.sleep(0.3)
      print(" r")
      time.sleep(0.3)
      print("  o")
      time.sleep(0.3)
      print("   c")
      time.sleep(0.3)
      print("    e")
      time.sleep(0.3)
      print("     s")
      time.sleep(0.3)
      print("      s")
      time.sleep(0.3)
      print("       i")
      time.sleep(0.3)
      print("        n")
      time.sleep(0.3)
      print("         g")
      time.sleep(0.3)
      print("          .")
      time.sleep(0.3)
      print("           .")
      time.sleep(0.3)
      print("            .")
      time.sleep(2)
      os.system('clear')
      
      print("Tēnā koutou you are correct!")
      
      print("Congratulations you have passed part 2 of Beginner quiz this is easiet quiz so you should try intermediate next.")
      print()
      Choosing_Options("Now that you have finished beginner here are some options.\n Options - 'Quit' 'Intermediate'")
      break  

    else:
      print("Try Again")



def intermediate_quiz():
  
  os.system('clear')
  intermediate_demonstration("Nau mai, Welcome to the intermediate quiz. Things are a bit different around here and the quiz setup is a bit different would you like to see a demonstration? ")




def intermediate_demonstration(question):  
  valid = False
  while not valid:
    intermediate_demonstration = input(question).lower()

    if intermediate_demonstration == "y" or intermediate_demonstration == "yes":
      demonstration_quiz()
      break
      

    

    else:
      print("Try Again")
      

def demonstration_quiz():
  os.system('clear')
  print("In the beginner quiz you were give words to remember but for this you will have a set of words to remember, and you will choose one of the 3 options.")
  print()
  next_slide("Press enter to continue... ")
  
def next_slide(question):
  valid = False
  while not valid:
    slide_next = input(question).lower()
    if slide_next == "" or slide_next == " ":
      this_next_slide()
      break

    else:
      print("Please press enter... ")
      break

def this_next_slide():
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("Please type answer here: <---- (You then write your answer in")

  time.sleep(5)
  print()
  print("Please type answer here: Purutaringa <---- (This is the answer)")
  print()
  print("Congratulations your correct! <---- (You will then be congratulated")
  print()
  print("A score will also be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("------------------------------------------------------")
  print()
  quiz_intermediates("Would you like to play? ")
 

def quiz_intermediates(question):
  valid = False
  while not valid:
    quiz_thing = input(question).lower()
    if quiz_thing == "y" or quiz_thing == "y":
      os.system('clear')
      quiz_intermediate()
      break

    if quiz_thing == "no" or quiz_thing == "n":
      os.system('clear')
      quiz_options()
      break


def quiz_options():
  quiz_option("You have the option to quit or try a different level what would you like to do? (Quit / Change level) ")


def quiz_option(question):
  valid = False
  while not valid:
    quiz_options = input(question).lower()
    if quiz_options == "Change level" or quiz_options == "c l":
      os.system('clear')
      level_choose()
      break

    if quiz_options == "Quit" or quiz_options == "q":
      os.system('clear')
      quit_game()
      break



def quit_game():
  os.system('clear')
  print("Tumeke! For giving the quiz a try, hope to see you again. Bye...")
  


def quiz_intermediate():
  # This defines the functions
  class Te_Reo_Question:
    def __init__(self, prompt, answer):
      # These define for prompt and answer these store information for a question
      self.prompt = prompt
      self.answer = answer


  # These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
  questions_prompts = [
    "What is Wahine is English?\n(1) Sister\n(2) Women / Female\n(3) Boat\n Answer Here: ",
    "\nWhat is Waka is English?\n(1) House\n(2) Toilet\n(3) Boat\n Answer Here: ",
    "\nWhat is Water is Te Reo?\n(1) Wai\n(2) Whare\n(3) Ika\n Answer Here: ",
    "\nWhat is Waimarie is English?\n(1) Happy\n(2) Luck\n(3) Good Luck\n Answer Here: ",
    "\nWhat is Computer is Te Reo?\n(1) Rorohiko\n(2) Rooroohiko\n(3) Roroheko\n Answer Here: ",  
    "\nWhat is Headphones is Te Reo?\n(1) Taringa\n(2) Pokitaringa\n(3) Kai\n Answer Here: ",
    "\nWhat is Tangi is English?\n(1) Sad\n(2) Death\n(3) Funeral\n Answer Here: ",
    "\nWhat is Happy is Te Reo?\n(1) Koa\n(2) Tumeke\n(3) Tena Koe\n Answer Here: ",
  ]


  # This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
  questions = [
    Te_Reo_Question(questions_prompts[0], "2"),
    Te_Reo_Question(questions_prompts[1], "3"),
    Te_Reo_Question(questions_prompts[2], "1"),
    Te_Reo_Question(questions_prompts[3], "3"),
    Te_Reo_Question(questions_prompts[4], "1"),
    Te_Reo_Question(questions_prompts[5], "2"),
    Te_Reo_Question(questions_prompts[6], "3"),
    Te_Reo_Question(questions_prompts[7], "1"),
    
    
  ]



  # This code will simply go through each question add a score and then tell you what your score was as the end.
  def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
    # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
    score = 0
    # For each question in questions it will do something which is told in the next code.
    for question in questions:
      # Ask user question then store response in a variable (answer)
      answer = input(question.prompt)
      # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
      if answer == question.answer:
        score += 1
      
      
        
    # This show how many questions they got right (have to use str since its a number for the score.))
    print()
    print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")
    print()
    advanced_quiz("Would you like to try advanced quiz, quit or continue to advanced?\n Options - 'Quit' 'Advanced' ")


  # This is to run the quiz this is all of the code from run_test to start the quiz.
  run_test(questions)

def advanced_quiz(question):
  valid = False
  while not valid:
    quiz_advanced = input(question).lower()
    if quiz_advanced == "a" or quiz_advanced == "Advanced":
      advanced_introduction()
      break
    

    if quiz_advanced == "q" or quiz_advanced == "quit":
      print("Ok. Thanks for playing, Bye...")
      break

    else:
      print("Please pick valid answer")


def advanced_introduction():
  os.system('clear')
  print("This is the advanced quiz") 
  advanced_demonstration("Would you like a demonstration?  ")


def advanced_demonstration(question):
  valid = False
  while not valid:
    quiz_demonstrate = input(question).lower()
    if quiz_demonstrate == "y" or quiz_demonstrate == "yes":
      advanced_demonstration_go()
      break
    

    if quiz_demonstrate == "n" or quiz_demonstrate == "no":
      playing_quiz_advanced()
      break

    else:
      print("Please pick valid answer")

    
def advanced_demonstration_go():
  os.system('clear')
  print("Similar to the intermediate quiz it will be a multiple choice question but with 4 options instead of 3 ")
  next_slide_go_advanced("Press enter to continue... ")


def next_advanced_slide():
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("4. Ika")
  print()
  print("Please type answer here: <---- (You then write your answer in")

  time.sleep(5)
  print()
  print("Please type answer here: Purutaringa <---- (This is the answer)")
  print()
  print("Congratulations your correct! <---- (You will then be congratulated")
  print()
  print("A score will also be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("------------------------------------------------------")
  print()
  play_advanced("Would you like to play? ")


def play_advanced(question):
  valid = False
  while not valid:
    advanced_play = input(question).lower()
    if advanced_play == "y" or advanced_play == "yes":
      playing_quiz_advanced()
      break

    if advanced_play == "n" or advanced_play == "no":
      print("Ok. Hope to see you again. Bye...")

    else:
      print("Please give a valid answer")


def playing_quiz_advanced():
  os.system('clear')
  print("Lets get straight into this quiz")
  class Te_Reo_Question_advanced:
    def __init__(self, prompt, answer):
      # These define for prompt and answer these store information for a question
      self.prompt = prompt
      self.answer = answer


  # These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
  questions_prompts = [
    "What is Aroha is English?\n(1) Love\n(2) Joy\n(3) Run\n(4) Jump\n Answer Here: ",
    "What is Welcome / Come in Te Reo?\n(1) Haere mai\n(2) Nau Haere\n(3) Nau mai\n(4) Whare paku\n Answer Here: ",
    "What is Pounamu in English?\n(1) Stone\n(2) Greenstone\n(3) Water\n(4) Pump\n Answer Here: ",
    "What is Wharepaku in English?\n(1) House\n(2) Toilet\n(3) Tribe\n(4) Stone\n Answer Here: ",
    "What is Keyboard in Te Reo?\n(1) None of these\n(2) heihei\n(3) Koti\n(4) Papapatuhi\n Answer Here: ",
    "What is Kaumatua in English?\n(1) Grandpa\n(2) Elder\n(3) Car\n(4) Solid State Drive\n Answer Here: ",
    "What is Manuhiri in English?\n(1) Guests / Visitors\n(2) Restaraunt\n(3) Meal\n(4) Prayer\n Answer Here: ",
  ]


  # This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
  questions = [
    Te_Reo_Question_advanced(questions_prompts[0], "1"),
    Te_Reo_Question_advanced(questions_prompts[1], "1"),
    Te_Reo_Question_advanced(questions_prompts[2], "2"),
    Te_Reo_Question_advanced(questions_prompts[2], "2"),
    Te_Reo_Question_advanced(questions_prompts[2], "4"),
    Te_Reo_Question_advanced(questions_prompts[2], "2"),
    Te_Reo_Question_advanced(questions_prompts[2], "1"),

    
    
  ]


  # This code will simply go through each question add a score and then tell you what your score was as the end.
  def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
    # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
    score = 0
    # For each question in questions it will do something which is told in the next code.
    for question in questions:
      # Ask user question then store response in a variable (answer)
      answer = input(question.prompt)
      # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
      if answer == question.answer:
        print("You are correct!")
        print()
        score += 1
      
      
        
    # This show how many questions they got right (have to use str since its a number for the score.))
    print()
    print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")


  # This is to run the quiz this is all of the code from run_test to start the quiz.
  run_test(questions)























def next_slide_go_advanced(question):
  valid = False
  while not valid:
    slide_go = input(question).lower()
    if slide_go == "" or slide_go == " ":
      next_advanced_slide()
      break

    else:
      print("Please press enter to continue")


def quiz_start():
  start_quiz("Press enter to start... ")

def start_quiz(question):
  valid = False
  while not valid:
    start_the_quiz = input(question).lower()
    if start_the_quiz == "" or start_the_quiz == " ":
      beginner_quiz()
      break

    else:
      print("Please press enter to start")


quiz_start()