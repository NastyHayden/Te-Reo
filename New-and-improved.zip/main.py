# This defines the functions
class Te_Reo_Question:
  def __init__(self, prompt, answer):
    # These define for prompt and answer these store information for a question
    self.prompt = prompt
    self.answer = answer


# These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
questions_prompts = [
  "What is Wahine is English?\n(1) Sister\n(2) Women / Female\n(3) Boat\n Answer Here: ",
  "\nWhat is Waka is English?\n(1) House\n(2) Toilet\n(3) Boat\n Answer Here: ",
  "\nWhat is Water is Te Reo?\n(1) Wai\n(2) Whare\n(3) Ika\n Answer Here: ",
  "\nWhat is Waimarie is English?\n(1) Happy\n(2) Luck\n(3) Good Luck\n Answer Here: ",
  "\nWhat is Computer is Te Reo?\n(1) Rorohiko\n(2) Rooroohiko\n(3) Roroheko\n Answer Here: ",  
  "\nWhat is Headphones is Te Reo?\n(1) Taringa\n(2) Pokitaringa\n(3) Kai\n Answer Here: ",
  "\nWhat is Tangi is English?\n(1) Sad\n(2) Death\n(3) Funeral\n Answer Here: ",
  "\nWhat is Happy is Te Reo?\n(1) Koa\n(2) Tumeke\n(3) Tena Koe\n Answer Here: ",
]


# This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
questions = [
  Te_Reo_Question(questions_prompts[0], "2"),
  Te_Reo_Question(questions_prompts[1], "3"),
  Te_Reo_Question(questions_prompts[2], "1"),
  Te_Reo_Question(questions_prompts[3], "3"),
  Te_Reo_Question(questions_prompts[4], "1"),
  Te_Reo_Question(questions_prompts[5], "2"),
  Te_Reo_Question(questions_prompts[6], "3"),
  Te_Reo_Question(questions_prompts[7], "1"),
  
  
]



# This code will simply go through each question add a score and then tell you what your score was as the end.
def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
  # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
  score = 0
  # For each question in questions it will do something which is told in the next code.
  for question in questions:
    # Ask user question then store response in a variable (answer)
    answer = input(question.prompt)
    # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
    if answer == question.answer:
      score += 1
    
    
      
  # This show how many questions they got right (have to use str since its a number for the score.))
  print()
  print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")


# This is to run the quiz this is all of the code from run_test to start the quiz.
run_test(questions)