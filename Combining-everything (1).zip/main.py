
# Version 1, Hayden French, 15.06.2021, Line 1 (Importing time and os for the quiz which help us with times where they need to see something for a certain amount of time and os is for clearing the screen)
import time
import os


# Version 1, Hayden French, 1/09/2021, (This is where the beginner quiz starts and it asks for a demonstration if answered yes it will show a demonstration if no then you will go to the quiz)
def beginner_quiz():
  os.system('clear')
  print("*** Beginner Quiz ***")
  print()
  print("Kia ora, This is the Beginner quiz, Goodluck!")
  print()
  beginner_demonstration("Would you like to see a demonstration? ")
  
  
  
# Version 1, Hayden French, 1/09/2021, (This will determine if they see a demonstartion or not depending on the users answer it will take the answer and if it is yes it will take them to a demonstration if no they go to the quiz but if they answer differently with a non option choice it will tell them to put in yes or no)
def beginner_demonstration(question):  
  valid = False
  while not valid:
    demonstration = input(question).lower()

    if demonstration == "y" or demonstration == "yes":
      demonstration_beginner()
      break  
    
    if demonstration == "n" or demonstration == "no":
      start_beginner()
      break

    else:
      print("Please answer Yes or No.")




# Version 1, Hayden French, 1/09/2021, (This is the beginner demonstartion and will show them how it will work with a full in depth detail on what to do and how to answer it will then ask them they want to start or not is yes they start if not then they dont else they will be asked to answer properly)
def demonstration_beginner():
  os.system('clear')
  print("*** Beginner Demonstration ***")
  print()
  print("You will be given a set of words. You will have to remember the set of words in 15 seconds.")
  print()
  print("Example...")
  print()
  print("Your Words - Goodluck (Waimarie), Chicken (HeiHei) etc...")
  print()
  print("You will get a question to answer if your correct you move on if your wrong you will have to keep trying til you get it.")
  print("What is 'Goodluck' in Te Reo? (Answer Here)")
  print()
  print("There will also be a hint if you need it, all you need to do is type 'hint'")
  print()
  print("This is what the beginner quiz will be like")
  print()
  beginner_start_quiz("Would you like to start? ")





# Version 1, Hayden French, 1/09/2021, (This is to determine whether or not they play the quiz if the user says yes they will start the quiz if they say no they wont start else it will tell them to answer with yes or no )
def beginner_start_quiz(question):  
  valid = False
  while not valid:
    start = input(question).lower()

    if start == "yes" or start == "y":
      start_beginner()
      break  

    if start == "no" or start == "n":
      print("Ok. You can always restart to try a quiz. Bye...")
      break
    

    else:
      print("Please answer Yes / No.")



# Version 1, Hayden French, 1/09/2021, (This is the beginner quiz the outcome if they said yes to starting the quiz they will have 15 seconds to remember there words and then the time.sleep and os.sytem('clear') activate and then they start answering the questions)
def start_beginner():
  os.system('clear')
  print("*** Beginner Quiz ***")
  print()
  print("Goodluck!")
  print()
  print("Remember these words...")
  print()
  print("Your words are - Hello (Kia Ora), Food (Kai), Mountain (Maunga)")
  time.sleep(15)
  os.system('clear')
  answer_hello()



# Version 1, Hayden French, 1/09/2021, (They will be asked what hello is if they get the answer right (kia ora) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def answer_hello():
  os.system('clear')
  
  print("What is 'Hello' in Te Reo? ")
  print()
  print("Type 'hint' for hint")
  print()
  hello_answer("Answer here:")


# Version 1, Hayden French, 01/09/2021 (This is the palce where the answer of the question is determined if they are right they will be congratulated if they say hint they get the hint else they will be asked to try again)
def hello_answer(question):  
  valid = False
  while not valid:
    hello = input(question).lower()

    if hello == "Kia ora" or hello == "kia ora":
      
      
      os.system('clear')
      print("processing...")
      time.sleep(3)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      answer_mountain()
      break  
    
    if hello == "hint" or hello == "h":
      os.system('clear')
      print("K_A _R_  (Fill in the blank)")
      time.sleep(7)
      answer_hello()
      break

    else:
      print()
      print("So close, Try again!")


# Version 1, Hayden French, 1/09/2021, (They will be asked what hello is if they get the answer right (kia ora) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def answer_mountain():
  os.system('clear')
  print("What is 'Mountain' in Te Reo? ")
  print()
  print("Type 'hint' for hint")
  print()
  mountain_answer("Answer here:")

# Version 1, Hayden French, 1/09/2021, (This is where it determines if the answer is correct. They will be asked what mountain is if they get the answer right (maunga) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)



# Version 1, Hayden French, 1/09/2021, (They will be asked what food is if they get the answer right (kai) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def mountain_answer(question):  
  valid = False
  while not valid:
    mountain = input(question).lower()

    if mountain == "Maunga" or mountain == "maunga":
      os.system('clear')
      print("processing...")
      time.sleep(3)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      answer_food()
      break

    if mountain == "hint" or mountain == "h":
      os.system('clear')
      print("This word ryhmes with 'taunga'")
      time.sleep(7)
      answer_mountain()
      break
 
    else:
      print("Try Again")




# Version 1, Hayden French, 1/09/2021,  They will be asked what food is if they get the answer right (kai) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def answer_food():
  os.system('clear')
  print("What is 'Food' in Te Reo? ")
  print()
  print("Type 'hint' for hint")
  print()
  food_answer("Answer here:")




# Version 1, Hayden French, 1/09/2021, (This is where it determines if the answer is correct or not. They will be asked what food is if they get the answer right (kai) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint then will congratulate them then ask what they want to do next which is either quit continue or go to intermediate)
def food_answer(question):  
  valid = False
  while not valid:
    food = input(question).lower()

    if food == "Kai" or food == "kai":
      
      os.system('clear')
      print("processing...")
      time.sleep(3)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      os.system('clear')
      print("Congratulations you passed part 1 of beginner!")
      time.sleep(5)
      os.system('clear')
      print("Would you like to continue with part 2 of the beginner quiz to increase your Te Reo vocabulary, or would you like to move on to intermediate or would you prefer to quit?")
      print()
      Choosing_Options("Options - 'Continue' 'Intermediate' 'Quit' ")
      break  

 
    if food == "hint" or food == "h":
      os.system('clear')
      print("K__ (fill in the black)")
      time.sleep(7)
      answer_food()
      break
   


    else:
      print("Please type an appropriate answer.")




# Version 1, Hayden French, 1/09/2021, (they get the option to continue quit or go to intermediate if they continue they wil be taken to beginner level part if they choose quit they will quit and the system will say bye and intermediate takes them to the intermediate introductione else it will tell them to answer one of the options)
def Choosing_Options(question):  
  valid = False
  while not valid:
    Option = input(question).lower()

    if Option == "c" or Option == "continue":
      continue_beginner()
      break  

    if Option == "i" or Option == "intermediate":
      intermediate_quiz()
      break


    if Option == "q" or Option == "quit":
      os.system('clear')
      print("Tumeke for what you have accomplished!\nHope to see you again but for now ka kite ano!")
      break
  
    else:
      print()
      print("Please pick 'Continue' 'Intermediate' 'Quit' ")    



# Version 1, Hayden French, 1/09/2021, (This is second part of beginner quiz if they chose to do beginner quiz part 2 it is the same as part 1 with different questions)
def continue_beginner():
  os.system('clear')
  print("*** Beginner quiz 2 ***")
  print("Here are your words - Good Morning (Ata marie), Good Night (Po marie), House (Whare)")
  print("Remember these.")
  time.sleep(10)
  os.system('clear')
  good_morning_answer()



# Version 1, Hayden French, 1/09/2021, (They will be asked what good morning is if they get the answer right (ata marie) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def good_morning_answer():
  os.system('clear')
  print("What is 'Good Morning' in Te Reo? ")
  print()
  print("Type 'hint' for hint")
  print()
  answer_good_morning("Answer here:")





# Version 1, Hayden French, 1/09/2021, (This is where it determines if the answer is correct or not. They will be asked what good morning is if they get the answer right (ata marie) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def answer_good_morning(question):  
  valid = False
  while not valid:
    good_morning = input(question).lower()

    if good_morning == "Ata marie" or good_morning == "ata marie":
      os.system('clear')
      print("processing...")
      time.sleep(2)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      good_night_answer()
      break  


    if good_morning == "hint" or good_morning == "h":
      os.system('clear')
      print("Ata _____ (fill in the black)")
      time.sleep(7)
      good_morning_answer()
      break
    


    else:
      print("Unlucky, Try again")




# Version 1, Hayden French, 1/09/2021, (They will be asked what good night is if they get the answer right (po marie) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def good_night_answer():
  os.system('clear')
  print("What is 'Good night' in Te Reo? ")
  print()
  print("Type 'hint' for hint")
  print()
  answer_good_night("Answer here:")




# Version 1, Hayden French, 1/09/2021, (This is where it determines if the answer is correct or not. They will be asked what good night is if they get the answer right (po marie) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def answer_good_night(question):  
  valid = False
  while not valid:
    good_night = input(question).lower()

    if good_night == "Po marie" or good_night == "po marie":
      
    
      os.system('clear')
      print("processing...")
      time.sleep(2)
      os.system('clear')
      print("Tēnā koutou you are correct!")
      time.sleep(3)
      house_answer()
      break  
    
    if good_night == "hint" or good_night == "h":
      os.system('clear')
      print("Po _____ (fill in the black)")
      time.sleep(7)
      good_night_answer()
      break
    
  

    else:
      print("Unlucky, Try again.")




# Version 1, Hayden French, 1/09/2021, (They will be asked what house is if they get the answer right (whare) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint)
def house_answer():
  os.system('clear')
  print("What is 'House' in Te Reo? ")
  print()
  print("Type 'hint' for hint")
  print()
  answer_house("Answer here:")



# Version 1, Hayden French, 1/09/2021, (This is where it determines if the answer is correct or not. They will be asked what house is if they get the answer right (whare) they will be congratulated and they can also type 'hint' for hint which then gives them a small hint and it will be erased after 7 seconds so they only get a small bit of a hint and they will also be congratulared for passing beginner part 2 and ask if they want to go to intermediate or quit)
def answer_house(question):  
  valid = False
  while not valid:
    house = input(question).lower()

    if house == "Whare" or house == "whare":
      
    
      os.system('clear')
      print("processing...")
      time.sleep(2)
      os.system('clear')
      
      print("Tēnā koutou you are correct!")
      
      print("Congratulations you have passed part 2 of Beginner quiz this is easiet quiz so you should try intermediate next.")
      print()
      Choosing_Options("Now that you have finished beginner here are some options.\n Options - 'Quit' 'Intermediate'")
      break  


    if house == "hint" or house == "h":
      os.system('clear')
      print("W_A_E(fill in the black)")
      time.sleep(7)
      house_answer()
      break
    

    else:
      print("Unlucky, Try again.")




# Version 1, Hayden French, 1/09/2021, (This is the start of inter mediate quiz they will be asked if they want to see a demonstration yes takes them to demonstration no takes them straight to quiz else they will be asked to answer properly
def intermediate_quiz():
  os.system('clear')
  print("*** Intermediate quiz ***")
  print()
  print("Nau mai, Welcome to the intermediate quiz.")
  print()
  intermediate_demonstration("Things are a bit different around here\nThe quiz setup is a bit different would you like to see a demonstration? ")





# Version 1, Hayden French, 1/09/2021, (This is where it determines where they go through the user input is yes they go to the demonstration if no they go straight to the quiz else they will be asked to answer yes /no
def intermediate_demonstration(question):  
  valid = False
  while not valid:
    intermediate_demonstration = input(question).lower()

    if intermediate_demonstration == "y" or intermediate_demonstration == "yes":
      demonstration_quiz()
      break
      
   
    if intermediate_demonstration == "n" or intermediate_demonstration == "no":
      os.system('clear')
      quiz_intermediate()
      break
    

    else:
      print("Please answer Yes / No")
      



# Version 1, Hayden French, 1/09/2021, (This is the intermediate demonstration where it will tell them how to answer and then tell them to press enter for next slide.)
def demonstration_quiz():
  os.system('clear')
  print("In the beginner quiz you were given words to remember\nbut for this you will have a set of words to remember,\nand you will choose one of the 3 then answer using one of the options you will answer with numbers rather than the actual word")
  print()
  next_slide("Press enter for next slide. ")
  


# Version 1, Hayden French, 1/09/2021, (This determines if they go to next slide if the user presses enter they will be taken to next slide else they will be asked to press enter)
def next_slide(question):
  valid = False
  while not valid:
    slide_next = input(question).lower()
    if slide_next == "" or slide_next == " ":
      this_next_slide()
      break

    else:
      print("Please press enter... ")
      break




# Version 1, Hayden French, 1/09/2021, (This is the next slide where it shows them a example and how the quiz will like and then ask if they would like to play)
def this_next_slide():
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("Please type answer here: <---- (You then write your answer in")
  print("Make sure you answer with numbers and not words.")
  time.sleep(5)
  print()
  print("Please type answer here: 1 <---- (This is the answer)")
  print()
  print("A score will also be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("------------------------------------------------------")
  print()
  quiz_intermediates("Would you like to play? ")
 



# Version 1, Hayden French, 1/09/2021, (This determines whether or not they play the game the user was aked would you like to play if they say yes they play if they say no they will be taken to a option on what to do else they will be asked to answer appropriately with yes / no. Also if they answer yes or no it will system clear the screen so it is easier to see everything )
def quiz_intermediates(question):
  valid = False
  while not valid:
    quiz_thing = input(question).lower()
    if quiz_thing == "yes" or quiz_thing == "y":
      os.system('clear')
      quiz_intermediate()
      break

    if quiz_thing == "no" or quiz_thing == "n":
      os.system('clear')
      quiz_options()
      break

    else:
      print("Please pick Yes / No")




# Version 1, Hayden French, 1/09/2021, (If the user answered no for the would you like to play the will be taken here and asked if they would like to quit or change level... )
def quiz_options():
  quiz_option("You have the option to quit or try a different level what would you like to do? (Quit / Change level) ")


# Version 1, Hayden French, 1/09/2021, (If the user answer with change level or c l they will be take to a level decider and if they say quit they will be told bye. else they will be told to answer properly)
def quiz_option(question):
  valid = False
  while not valid:
    quiz_options = input(question).lower()
    if quiz_options == "Change level" or quiz_options == "c l":
      os.system('clear')
      level_choose()
      break

    if quiz_options == "Quit" or quiz_options == "q":
      os.system('clear')
      quit_game()
      break
    
    else:
      print("Please answer properly")



# Version 1, Hayden French, 1/09/2021, (If the user answered change level they will be taken here this will ask them if they want to go to beginner or advanced... )
def level_choose():
  choose_level("Would you like to go to Beginner or Advanced? ")


# Version 1, Hayden French, 1/09/2021, (If they answer advanced they will be taken to advanced quiz if they answer beginner they will be take to beginner else they will be told to answer properly)
def choose_level(question):
  valid = False
  while not valid:
    quiz_advanced = input(question).lower()
    if quiz_advanced == "a" or quiz_advanced == "Advanced":
      advanced_quiz_start()
      break
    

    if quiz_advanced == "b" or quiz_advanced == "Beginner":
      beginner_quiz()
      break

    else:
      print("Please pick valid answer")



# Version 1, Hayden French, 1/09/2021, (This is here for whenever someone says quit on the quit option this will just tell they a goodbye message)
def quit_game():
  os.system('clear')
  print("Tumeke! For giving the quiz a try, hope to see you again. Bye...")
  

# Version 1, Hayden French, 1/09/2021, (This is the actual intermediate quiz)
def quiz_intermediate():
  # This defines the functions
  class Te_Reo_Question:
    def __init__(self, prompt, answer):
      # These define for prompt and answer these store information for a question
      self.prompt = prompt
      self.answer = answer


  # These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
  questions_prompts = [
    "What is Wahine is English?\n(1) Sister\n(2) Women / Female\n(3) Boat\n Answer Here: ",
    "\nWhat is Waka is English?\n(1) House\n(2) Toilet\n(3) Boat\n Answer Here: ",
    "\nWhat is Water is Te Reo?\n(1) Wai\n(2) Whare\n(3) Ika\n Answer Here: ",
    "\nWhat is Waimarie is English?\n(1) Happy\n(2) Luck\n(3) Good Luck\n Answer Here: ",
    "\nWhat is Computer is Te Reo?\n(1) Rorohiko\n(2) Rooroohiko\n(3) Roroheko\n Answer Here: ",  
    "\nWhat is Headphones is Te Reo?\n(1) Taringa\n(2) Pokitaringa\n(3) Kai\n Answer Here: ",
    "\nWhat is Tangi is English?\n(1) Sad\n(2) Death\n(3) Funeral\n Answer Here: ",
    "\nWhat is Happy is Te Reo?\n(1) Koa\n(2) Tumeke\n(3) Tena Koe\n Answer Here: ",
  ]


  # This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
  questions = [
    Te_Reo_Question(questions_prompts[0], "2"),
    Te_Reo_Question(questions_prompts[1], "3"),
    Te_Reo_Question(questions_prompts[2], "1"),
    Te_Reo_Question(questions_prompts[3], "3"),
    Te_Reo_Question(questions_prompts[4], "1"),
    Te_Reo_Question(questions_prompts[5], "2"),
    Te_Reo_Question(questions_prompts[6], "3"),
    Te_Reo_Question(questions_prompts[7], "1"),
    
    
  ]



  # This code will simply go through each question add a score and then tell you what your score was as the end.
  def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
    # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
    score = 0
    # For each question in questions it will do something which is told in the next code.
    for question in questions:
      # Ask user question then store response in a variable (answer)
      answer = input(question.prompt)
      # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
      if answer == question.answer:
        print()
        print("You are correct!")
        print()
        score += 1
      
      
        
    # This show how many questions they got right (have to use str since its a number for the score.))
    print()
    print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")
    print()
    advanced_quiz("Would you like to try advanced quiz, quit or continue to advanced?\n Options - 'Quit' 'Advanced' ")


  # This is to run the quiz this is all of the code from run_test to start the quiz.
  run_test(questions)



# Version 1, Hayden French, 1/09/2021, (This is the determination of the users input if they say advanced they will start advanced quiz)
def advanced_quiz(question):
  valid = False
  while not valid:
    quiz_advanced = input(question).lower()
    if quiz_advanced == "a" or quiz_advanced == "advanced":
      advanced_quiz_start()
      break
    
    # Version 1, Hayden French, 1/09/2021, (If they say quit they will be told goodbye)
    if quiz_advanced == "q" or quiz_advanced == "quit":
      print("Ok. Thanks for playing, Bye...")
      break


    # Version 1, Hayden French, 1/09/2021, (Else they will be told to answer properly)
    else:
      os.system('clear')
      print("Please pick valid answer")



# Version 1, Hayden French, 1/09/2021, (This is the start of the advanced quiz and ask if they would like to see a demonstration...)
def advanced_quiz_start():
  os.system('clear')
  print("*** Advanced Quiz ***")
  print()
  print("Nau Mai, Haere Mai, This is the advanced quiz") 
  advanced_demonstration("Would you like a demonstration? ")



# Version 1, Hayden French, 1/09/2021, (If they answer yes to demonstartion they will be taken to a demonstration if no they will be taken to the quiz else they will be told to answer properly)
def advanced_demonstration(question):
  valid = False
  while not valid:
    quiz_demonstrate = input(question).lower()
    if quiz_demonstrate == "y" or quiz_demonstrate == "yes":
      advanced_demonstration_go()
      break
    

    if quiz_demonstrate == "n" or quiz_demonstrate == "no":
      playing_quiz_advanced()
      break

    else:
      print("Please pick valid answer")



# Version 1, Hayden French, 1/09/2021, (This is the advanced demonstration and it will tell them how to do the quiz and the will be a press enter for next slide )
def advanced_demonstration_go():
  os.system('clear')
  print("*** Advanced demonstration ***")
  print()
  print("Similar to the intermediate quiz it will be a multiple choice question\nbut with 4 options instead of 3 you will answer using the numbers and not the words.")
  print()
  next_slide_go_advanced("Press enter for next slide... ")



# Version 1, Hayden French, 1/09/2021, (This a demonstration on how to play and what it will like then they will be asked if they want to start)
def next_advanced_slide():
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("4. Ika")
  print()
  print("Please type answer here: <---- (You then write your answer in")
  time.sleep(5)
  print()
  print("Please type answer here: 1 <---- (This is the answer)")
  print("Make sure you are answering with numbers and not the word.")
  print()
  print("Congratulations your correct! <---- (You will then be congratulated")
  print()
  print("A score will also be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("------------------------------------------------------")
  print()
  play_advanced("Would you like to play? ")



# Version 1, Hayden French, 1/09/2021, (If they answer yes they will be taken to the quiz else they will be told bye else they will be told to answer properly)
def play_advanced(question):
  valid = False
  while not valid:
    advanced_play = input(question).lower()
    if advanced_play == "y" or advanced_play == "yes":
      playing_quiz_advanced()
      break

    if advanced_play == "n" or advanced_play == "no":
      print("Ok. Hope to see you again. Bye...")

    else:
      print("Please give a valid answer")


# Version 1, Hayden French, 1/09/2021, (This is the advanced quiz)
def playing_quiz_advanced():
  os.system('clear')
  print("*** Advanced quiz ***")
  print()
  class Te_Reo_Question_advanced:
    def __init__(self, prompt, answer):
      # These define for prompt and answer these store information for a question
      self.prompt = prompt
      self.answer = answer


  # These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
  questions_prompts = [
    "What is Aroha is English?\n(1) Love\n(2) Joy\n(3) Run\n(4) Jump\n Answer Here: ",
    "What is Welcome / Come in Te Reo?\n(1) Haere mai\n(2) Nau Haere\n(3) Nau mai\n(4) Whare paku\n Answer Here: ",
    "What is Pounamu in English?\n(1) Stone\n(2) Greenstone\n(3) Water\n(4) Pump\n Answer Here: ",
    "What is Wharepaku in English?\n(1) House\n(2) Toilet\n(3) Tribe\n(4) Stone\n Answer Here: ",
    "What is Keyboard in Te Reo?\n(1) None of these\n(2) heihei\n(3) Koti\n(4) Papapatuhi\n Answer Here: ",
    "What is Kaumatua in English?\n(1) Grandpa\n(2) Elder\n(3) Car\n(4) Solid State Drive\n Answer Here: ",
    "What is Manuhiri in English?\n(1) Guests / Visitors\n(2) Restaraunt\n(3) Meal\n(4) Prayer\n Answer Here: ",
  ]


  # This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
  questions = [
    Te_Reo_Question_advanced(questions_prompts[0], "1"),
    Te_Reo_Question_advanced(questions_prompts[1], "1"),
    Te_Reo_Question_advanced(questions_prompts[2], "2"),
    Te_Reo_Question_advanced(questions_prompts[3], "2"),
    Te_Reo_Question_advanced(questions_prompts[4], "4"),
    Te_Reo_Question_advanced(questions_prompts[5], "2"),
    Te_Reo_Question_advanced(questions_prompts[6], "1"),
    
  ]


  # This code will simply go through each question add a score and then tell you what your score was as the end.
  def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
    # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
    score = 0
    # For each question in questions it will do something which is told in the next code.
    for question in questions:
      # Ask user question then store response in a variable (answer)
      answer = input(question.prompt)
      # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
      if answer == question.answer:
        print()
        print("You are correct!")
        print()
        score += 1
      
    
    # This show how many questions they got right (have to use str since its a number for the score.))
    print()
    print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")


  # This is to run the quiz this is all of the code from run_test to start the quiz.
  run_test(questions)


# Version 1, Hayden French, 1/09/2021, (This is where it determines if they go to next slide if they press enter they will else they will be told to press enter)
def next_slide_go_advanced(question):
  valid = False
  while not valid:
    slide_go = input(question).lower()
    if slide_go == "" or slide_go == " ":
      next_advanced_slide()
      break

    else:
      print("Please press enter to continue")
  





# Version 1, Hayden French, 15.06.2021, Line (defing yes and no when asking questions)
def yes_no(question):  
  valid = False
  while not valid:
    response = input(question).lower()

    if response == "yes" or response == "y":
      response == "yes"
      return response

    elif response == "no" or response == "n":
      response == "no"
      return response

    else:
      print("Please answer yes / no")
      


        
# Version 1, Hayden French, 15.06.2021, Line (Welcome to the Te Reo Quiz)
print("Kia ora nau mai ki te patapatai o Te Reo Maori...")
print()
print("Welcome to the Te Reo Maori quiz...")
print()
print("We'll be teaching and learning together in this quiz to help you develop your Te Reo Maori vocabulary, confidence, and pronounciation.\n")

# Version 1, Hayden French, 29.06.2021, Line (This is beginner quiz if you chose beginner and there is also a demonstraion if wanted else go straight into the quiz)
def level_beginners():
  print()
  print("*** Beginner Quiz ***")
  print()
  print("Ok beginner, lets start off with a basic quiz. ")
  print()
  



# Version 1, Hayden French, 29.06.2021, Line (This is intermediate quiz if you chose intermediate and there is also a demonstration if wanted else go straight into the quiz)
def level_intermediates():
  print()
  print("*** Intermediate Quiz ***")
  print()
  


# Version 1, Hayden French, 1/09/2021, (This is the advanced quiz if they choose advanced they will be taken to the introduction)
def level_advanced():
  print()
  print("*** Patapatai matatau ***")
  print()

 

# Version 1, Hayden French, 29.06.2021, Line  (Defining a question so that when you type an answer thats not valid it will say 'Please pick a sensible answer!')
def yes_no_level(question):  
  valid = False
  while not valid:
    response = input(question).lower()

    if response == "beginner" or response == "b":
      beginner_quiz()
      break

    if response == "intermediate" or response == "i":
      intermediate_quiz()
      break
    
    elif response == "advanced" or response == "a":
      advanced_quiz_start()
      break

    else:
      print("Please pick one of the options. \nOptions - 'Beginner' 'Intermediate' 'Advanced'")



# Version 1, Hayden French, 1/09/2021, (This determines there level depending on the users input if they answer beginner they will be taken to beginner if intermediate they will go intermediate if advanced they go to advanced else asked to put proper answer)
def level():
  os.system('clear')
  print("*** Level Determination ***")
  print()
  print("There are 3 levels of learning beginner, intermediate, advanced")
  yes_no_level("What level of Te Reo Maori do you think your at? ")

  return""
  



def enter_level():
  print("Lets determine your level of Te Reo Maori")
  enter("Press Enter to continue... ")



def enter(question):  
  valid = False
  while not valid:
    enter = input(question).lower()

    if enter == "" or enter == " ":
      level()
      break

    else:
      print("Please press enter. ")



# Version 1, Hayden French, 15.06.2021, Line  (Embarking on this journey)
embark_journey = yes_no("Would you like to embark on this journey? ")



# Version 1, Hayden French, 15.06.2021, Line (If yes, print Lets do this)
if embark_journey == "yes" or embark_journey =="y":
 
  os.system('clear')
  print("Ka Pai! Lets do this")
  enter_level()



# Version 1, Hayden French, 15.06.2021, Line (If no, print fairwell...)
if embark_journey == "no" or embark_journey == "n":
  print()
  print("Kei a koe te mea pai engari kei te akiaki ahau kia tukuna e koe kia whai waahi ano ka whai waahi koe...")
  print()
  print("It's your choice, but I recommend that you try it the next time you get the chance.")








  



