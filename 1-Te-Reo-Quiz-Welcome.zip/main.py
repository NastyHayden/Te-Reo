# Version 1, Hayden French, 15.06.2021, (Welcome)



# Version 1, Hayden French, 15.06.2021, Line 1 (defing yes and no when asking questions)
def yes_no(question):  
  valid = False
  while not valid:
    response = input(question).lower()

    if response == "yes" or response == "y":
      response == "yes"
      return response

    elif response == "no" or response == "n":
      response == "no"
      return response

    else:
      print("Please answer yes / no")


        
# Version 1, Hayden French, 15.06.2021, Line 2 (Welcome to the Te Reo Quiz)
print("Kia ora nau mai ki te patapatai o Te Reo Maori...")
print()
print("Welcome to the Te Reo Maori quiz...")
print()
print("We'll be teaching and learning together in this quiz to help you develop your Te Reo Maori vocabulary, confidence, and pronounciation.\n")



# Version 1, Hayden French, 15.06.2021, Line 2 (Embarking on this journey)
embark_journey = yes_no("Would you like to embark on this journey? ")



# Version 1, Hayden French, 15.06.2021, Line 4 (If yes, print Lets do this)
if embark_journey == "yes" or embark_journey =="y":
  print()
  print("Ka Pai! Lets do this")



# Version 1, Hayden French, 15.06.2021, Line 5 (If no, print fairwell...)
if embark_journey == "no" or embark_journey == "n":
  print()
  print("Kei a koe te mea pai engari kei te akiaki ahau kia tukuna e koe kia whai waahi ano ka whai waahi koe...")
  print()
  print("It's your choice, but I recommend that you try it the next time you get the chance.")