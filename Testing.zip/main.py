import os
import time


def advanced_introduction():
  os.system('clear')
  advanced_demonstration("This is the advanced quiz, would you like a demonstration?")


def advanced_demonstration(question):
  valid = False
  while not valid:
    quiz_demonstrate = input(question).lower()
    if quiz_demonstrate == "y" or quiz_demonstrate == "yes":
      advanced_demonstration_go()
      break
    

    if quiz_demonstrate == "n" or quiz_demonstrate == "no":
      playing_quiz_advanced()
      break

    else:
      print("Please pick valid answer")

    
def advanced_demonstration_go():
  os.system('clear')
  print("Similar to the intermediate quiz it will be a multiple choice question but with 4 options instead of 3 ")
  next_slide_go_advanced("Press enter to continue... ")


def next_advanced_slide():
  os.system('clear')
  print("Please do not type or touch the screen!")
  print()
  print("Here is a demonstration...")
  print()
  print("What is 'headphones' in Te Reo")
  print()
  print("1. Purutaringa")
  print()
  print("2. Potai")
  print()
  print("3. Tuuru")
  print()
  print("4. Ika")
  print()
  print("Please type answer here: <---- (You then write your answer in")

  time.sleep(5)
  print()
  print("Please type answer here: Purutaringa <---- (This is the answer)")
  print()
  print("Congratulations your correct! <---- (You will then be congratulated")
  print()
  print("A score will also be kept and it will go up by 1 if you get it right and if your wrong it will stay the same")
  print("------------------------------------------------------")
  print()
  play_advanced("Would you like to play? ")


def play_advanced(question):
  valid = False
  while not valid:
    advanced_play = input(question).lower()
    if advanced_play == "y" or advanced_play == "yes":
      playing_quiz_advanced()
      break

    if advanced_play == "n" or advanced_play == "no":
      advanced_options()

    else:
      print("Please give a valid answer")


def playing_quiz_advanced():
  os.system('clear')
  print("Lets get straight into this quiz")
  class Te_Reo_Question_advanced:
    def __init__(self, prompt, answer):
      # These define for prompt and answer these store information for a question
      self.prompt = prompt
      self.answer = answer


  # These are the questions in a list so it is easier to manage and also in a list because we canuse the code (question_prompts) to pull out a question very easily instead of my old code which had a def for each code
  questions_prompts = [
    "What is Aroha is English?\n(1) Love\n(2) Joy\n(3) Run\n(4) Jump\n Answer Here: ",
    "What is Welcome / Come is Te Reo?\n(1) Haere mai\n(2) Nau Haere\n(3) Nau mai\n(4) Whare paku\n Answer Here: ",
    "What is Aroha is English?\n(1) Love\n(2) Joy\n(3) Run\n(4) Jump\n Answer Here: ",
  ]


  # This code is for all the questions and there answer we bring this code out from question_prompts and Te_Reo_Question whcih have our self, our answer and our prompt. We bring the questions out in order from what we typed by using 0, 1, 2... so on and the answer is the numbers after the question "2", "3", "1"... so on. 
  questions = [
    Te_Reo_Question_advanced(questions_prompts[0], "1"),
    Te_Reo_Question_advanced(questions_prompts[1], "3"),
    Te_Reo_Question_advanced(questions_prompts[2], "1"),

    
    
  ]



  # This code will simply go through each question add a score and then tell you what your score was as the end.
  def run_test(questions):  # <----- this questions code was pulled from questions which will simply show all the questions when we use the code answer = input(question.prompt)
    # The score will start at 0 and depending on whether an answer is right or not it will go up by 1.
    score = 0
    # For each question in questions it will do something which is told in the next code.
    for question in questions:
      # Ask user question then store response in a variable (answer)
      answer = input(question.prompt)
      # Check if answer for question is right. Checking to see if answer given is equal to current question if it is true then we add a score (+ 1 per right answer)
      if answer == question.answer:
        score += 1
      
      
        
    # This show how many questions they got right (have to use str since its a number for the score.))
    print()
    print("Your quiz is finished and you got " + str(score) + "/" + str(len(questions)) + " correct!")


  # This is to run the quiz this is all of the code from run_test to start the quiz.
  run_test(questions)




def next_slide_go_advanced(question):
  valid = False
  while not valid:
    slide_go = input(question).lower()
    if slide_go == "" or slide_go == " ":
      next_advanced_slide()
      break

    else:
      print("Please press enter to continue")


advanced_introduction()